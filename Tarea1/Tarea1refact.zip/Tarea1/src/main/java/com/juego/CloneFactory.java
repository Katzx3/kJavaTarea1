package com.juego;

public class CloneFactory {

    public Monster copiar(Monster muestraMonstruo){

        return muestraMonstruo.copiar();
    }

}
