package com.juego;


import java.io.IOException;

public class cliente {

    public static void main(String[] args) throws IOException {
        //mundo nivel2 = new mundo(20,50,"*");
        //nivel2.dibujo();
        //System.out.println(" ");

        mapa nuevoNivel = new mapa();
        nuevoNivel.plantillaMapa();

        //System.out.println(" ");

        //personaje heroe1 = new Heroe();
        //heroe1.accionArma();
        //heroe1.accionItems();
        //heroe1.accionMagia();
       // heroe1.display();

        //System.out.println(" ");

       // personaje Magus = new Villano();
        ////Magus.accionMagia();
        //Magus.accionPelear();
        //Magus.accionArma();

        //CloneFactory nuevoClon = new CloneFactory();
        //Bat dracula = new Bat();
        //Bat clonedBat = (Bat) nuevoClon.copiar(dracula);
        //System.out.println(dracula);



    }
}
