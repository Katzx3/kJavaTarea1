package com.juego;

public interface PeleaConducta {
    public void pelear();
}
