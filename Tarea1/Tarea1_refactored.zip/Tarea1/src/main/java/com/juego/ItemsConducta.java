package com.juego;

public interface ItemsConducta {

    public void items();
}
