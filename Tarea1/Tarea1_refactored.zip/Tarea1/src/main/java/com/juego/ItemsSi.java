package com.juego;

public class ItemsSi implements ItemsConducta{
    @Override
    public void items() {
        System.out.println("El personaje puede usar items");
    }
}
