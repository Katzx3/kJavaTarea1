package com.juego;

public class ArmaSi implements ArmaConducta{
    @Override
    public void arma() {
        System.out.println("El personaje puede portar armas");
    }
}
