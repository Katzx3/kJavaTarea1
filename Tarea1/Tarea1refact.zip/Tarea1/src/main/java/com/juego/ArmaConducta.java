package com.juego;

public interface ArmaConducta {

    public void arma();
}
