package com.juego;

public class MagiaSi implements MagiaConducta{
    @Override
    public void magia() {
        System.out.println("El personaje puede usar Magia");
    }
}
