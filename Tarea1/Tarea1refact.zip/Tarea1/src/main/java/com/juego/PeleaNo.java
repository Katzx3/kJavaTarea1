package com.juego;

public class PeleaNo implements PeleaConducta{

    @Override
    public void pelear() {
        System.out.println("El personaje no pelea");
    }
}
