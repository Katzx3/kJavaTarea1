package com.juego;

public class PeleaSi implements PeleaConducta{
    @Override
    public void pelear() {
        System.out.println("El personaje pelea");
    }
}
