package com.juego;

public class ItemsNo implements ItemsConducta{

    @Override
    public void items() {
        System.out.println("El personaje no puede usar Items");
    }
}
