package com.juego;

public interface MagiaConducta {

    public void magia();
}
