package com.juego;

public interface Monster extends Cloneable{

    public Monster copiar();

}
